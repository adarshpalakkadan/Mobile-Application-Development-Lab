package com.example.shared;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText name,email;
    Button b1,b2;
    SharedPreferences sh;
    TextView v1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name=findViewById(R.id.editTextText);
        email=findViewById(R.id.editTextText2);
        b1=findViewById(R.id.button);
        b2=findViewById(R.id.button2);
        sh=getSharedPreferences("user",MODE_PRIVATE);
        v1=findViewById(R.id.textView3);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String n1 = name.getText().toString();
                String e1 = email.getText().toString();

                SharedPreferences.Editor editor = sh.edit();
                editor.putString("name1", n1);
                editor.putString("email1", e1);
                editor.apply();

            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String n2 = sh.getString("name1", "");
                String e2 = sh.getString("email1", "");

                v1.setText("name: " + n2
                        + " email: " + e2);

            }
        });


    }
}